// Cartmain.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Cart.h"


int main()
{
	Cart*c1 = new Cart();
	Cart*c2 = new Cart();
	Cart*c3 = new Cart();

	c1->addcartitem();
	c2->addcartitem();
	c3->addcartitem();

	c1->updateQuantity();
	c2->updateQuantity();
	c3->updateQuantity();

	c1->viewCartDetails();
	c2->viewCartDetails();
	c3->viewCartDetails();

	c1->checkOut();
	c2->checkOut();
	c3->checkOut();
    return 0;
}

