#pragma once
#include<string>
#define SIZE 10

using namespace std;
class Cart  // cart class
{
private:   // Attributes
	int cartId;
	int productId;
	int quantity;
	int dateAdded;

public:   // methods
	Cart();
	Cart(int cID, int pId, int qty, int dAdded);
	void addcartitem();
	void updateQuantity();
	void viewCartDetails();
	void checkOut();
	~Cart();
};
