
#include "Promotion.h"


int main()
{
	Promotion*pro1 = new Promotion();
	Promotion*pro2 = new Promotion();
	Promotion*pro3 = new Promotion();

	pro1->setpromotionID(110);
	pro2->setpromotionID(111);
	pro3->setpromotionID(112);

	pro1->Promotion(110,"kamal","kamal@gmail.com");
	pro2->Promotion(111,"kumar","kumar@gmail.com");
	pro3->Promotion(112,"Ajith","ajith@gmail.com");
	
    return 0;
}

