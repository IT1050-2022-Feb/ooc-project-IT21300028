#pragma once
#include<string>
#define SIZE 10

using namespace std;
class Promotion  // cart class
{
private:   // Attributes
	int promotionId;
	string name;
	string email;

public:   // methods
	Promotion();
	void setpromotionID(int rID);
	Promotion(int promotionID, string name, string email);
	~Promotion();
};

