#include "stdafx.h"
#include "Cart.h"


Cart::Cart()
{
	cartId = 0;
	productId = 0;
	quantity = 0;
	dateAdded = 0;
}

Cart::Cart(int cID, int pId, int qty, int dAdded)
{
	cartId = cID;
	productId = pId;
	quantity = qty;
	dateAdded = dAdded;
}

void Cart::addcartitem()
{
}

void Cart::updateQuantity()
{
}

void Cart::viewCartDetails()
{
}

void Cart::checkOut()
{
}


Cart::~Cart()
{
}
