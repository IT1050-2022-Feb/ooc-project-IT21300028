
#include "Promotion.h"




	Promotion::Promotion()
	{
		promotionId = 0;
		name = "";
		email = "";
	}

	void Promotion::setpromotionID(int rID)
	{
		promotionId = rID;
	}

	Promotion::Promotion(int promotionID, string name, string email)
	{
		promotionId = promotionID;
		name = name;
		email = email;
	}


	Promotion::~Promotion()
	{
	}

 
